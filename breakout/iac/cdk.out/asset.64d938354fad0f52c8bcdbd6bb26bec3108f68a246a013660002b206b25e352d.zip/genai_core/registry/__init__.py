from .index import AdapterRegistry

registry = AdapterRegistry()
